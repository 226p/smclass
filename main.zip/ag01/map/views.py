from django.shortcuts import render

def mview(request):
  return render(request, 'mview.html')

def test(request):
  return render(request, 'test.html')