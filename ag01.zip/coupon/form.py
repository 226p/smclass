# from django import forms
 
# class AddCouponForm(forms.Form): # 쿠폰 데이터 코드 전달
#   quantity = forms.IntegerField() # 쿠폰 수량 
#   is_update = forms.BooleanField(required=False, initial=False, widget=forms.HiddenInput) # 수량을 추가할 때마다 더해짐
